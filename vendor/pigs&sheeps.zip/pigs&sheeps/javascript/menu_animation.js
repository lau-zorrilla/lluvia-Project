///YA NO HACE FALTA ESTE ARCHIVOOOO


function change_image(){
   menu_img.src="images/sheep2.png"
}

function first_image(){
    menu_img.src="images/sheep1.png"
}

